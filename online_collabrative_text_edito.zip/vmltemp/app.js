const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const socketIo = require('socket.io');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const io = socketIo(server);




app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const scheme_data = mongoose.Schema({
  username: String,
  password: String,
});

app.get("/", function (req, res) {
  res.render("login");
});

app.get("/signup", function (req, res) {
  res.render("signup");
});
  
app.get('/editor', async (req, res) => 
{
  
  
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/Save', async (req, res) => 
  {
    
    const content = document.getElementById('editor').innerHTML;
    downloadFile('document.html', content);
  });
  
// Handle WebSocket connections
io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('editorContent', (content) => {
      socket.broadcast.emit('editorContent', content);
  });

  socket.on('disconnect', () => {
      console.log('User disconnected');
  });
});


mongoose.connect('mongodb://localhost:27017/login', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => { console.log('Connected') })
  .catch((err) => { console.log(err) });

var data = mongoose.model('user_info', scheme_data);
var db = mongoose.connection;

app.post('/insert', async (req, res) => {
  var user = {
    username: `${req.body.username}`,
    password: `${req.body.password}`,
  }

  const fun = async () => {
    const result = await data.insertMany(user);
    console.log(result);
    res.render('login');
  }
  fun();
});

app.post('/verify', async (req, res) => {
  const fun = async () => {
    const result = await data.find({ username: `${req.body.username}` });
    console.log(result);
    if (result.length > 0) {
      for (let x in result) {
        if (req.body.username === result[x].username && req.body.password === result[x].password) {
          console.log("index2 opened");
          res.sendFile(__dirname + "/index2.html");
        }
        else {
          res.send('not login');
        }
      }
    }
    else {
      res.send('Not Login');
    }
  }
  fun();
});

wss.on('connection', (ws) => {
  console.log('New WebSocket connection established');

  // Handle incoming messages from clients
  ws.on('message', (message) => {
    try {
      const parsedMessage = JSON.parse(message);

      if (parsedMessage.type === 'generateId') {
        // Generate a unique ID
        const connectionId = uuidv4();
        
        // Send the connection ID to the client
        ws.send(JSON.stringify({ type: 'connectionId', id: connectionId }));
        
        // Display the connection ID in the server console
        console.log(`Generated WebSocket ID: ${connectionId}`);
      } else if (parsedMessage.type === 'update') {
        // Broadcast the update to all clients
        wss.clients.forEach((client) => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(message);
          }
        });
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  });

  // Handle WebSocket closure
  ws.on('close', () => {
    console.log('WebSocket connection closed');
  });

  // Handle WebSocket errors
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

// Start the server
const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`Server is listening on http://localhost:${port}`);
});
